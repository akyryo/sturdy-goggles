let dataset = [];

// Загрузка датасета из JSON-файла
function loadDataset() {
  fetch(chrome.runtime.getURL("dataset.json"))
    .then((response) => response.json())
    .then((data) => {
      dataset = data;
      console.log("Dataset loaded:", dataset);
    })
    .catch((error) => console.error("Error loading dataset:", error));
}

// Анализируем ссылку на основе модели
function analyzeUrl(url) {
  try {
    const urlObj = new URL(url);

    const features = {
      length: urlObj.hostname.length,
      subdomains: urlObj.hostname.split(".").length - 2,
      suspicious_tld: [".xyz", ".info", ".club", ".tk"].includes(urlObj.hostname.split(".").slice(-1)[0]) ? 1 : 0,
      https: url.startsWith("https://") ? 0 : 1,
      keywords: ["login", "verify", "secure"].some((keyword) => url.includes(keyword)) ? 1 : 0
    };
    console.log(features[0]);
    // Ищем точное совпадение в датасете
    const match = dataset.find((entry) => entry.url === url);

    if (match) {
      return match.label === "Phishing" ? "Phishing" : "Safe";
    } else {
      // Если точного совпадения нет, используем модель www.gosuslugi.ru
      const score = (
        0.03 * features.length +
        0.3 * features.subdomains +
        0.7 * features.suspicious_tld +
        0.2 * features.https +
        1.0 * features.keywords
      );

      return score >= 2 ? "Phishing" : "Safe";
    }
  } catch (error) {
    console.error("Invalid URL:", error);
    return "Invalid URL";
  }
}

// Создаем всплывающее окно на странице
function createPopup(result, url) {
  const popup = document.createElement("div");
  popup.style.position = "fixed";
  popup.style.bottom = "20px";
  popup.style.right = "20px";
  popup.style.backgroundColor = result === "Phishing" ? "red" : "green";
  popup.style.color = "white";
  popup.style.padding = "15px";
  popup.style.borderRadius = "5px";
  popup.style.zIndex = "9999";
  popup.style.boxShadow = "0 2px 10px rgba(0, 0, 0, 0.2)";
  popup.style.fontSize = "14px";
  popup.style.maxWidth = "300px";

  const title = result === "Phishing" ? "Фишинговая ссылка!" : "Безопасная ссылка!";
  popup.innerHTML = `
    <strong>${title}</strong><br>
    <small>${url}</small>
  `;

  document.body.appendChild(popup);

  setTimeout(() => {
    popup.remove();
  }, 5000);
}

// Контекстное меню для проверки ссылки
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "analyzeUrl",
    title: "Проверить ссылку на фишинг",
    contexts: ["link"]
  });

  // Загружаем датасет
  loadDataset();
});

// Обработка клика по пункту контекстного меню
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "analyzeUrl") {
    const result = analyzeUrl(info.linkUrl);
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: createPopup,
      args: [result, info.linkUrl]
    });
  }
});
